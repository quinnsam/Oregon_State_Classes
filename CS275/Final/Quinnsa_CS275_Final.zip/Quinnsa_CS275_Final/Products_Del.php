<?php require_once("common_db.inc.php") ?>
<?php   
$url = 'http://web.engr.oregonstate.edu/~quinnsa/Products.php';
$_item = $_GET["Item_ID"];
$_del = $_GET["check_option"];
echo $_item;
echo $_del;
if($_del != NULL) {
	echo $_item;
	mysqli_query($Link,"DELETE FROM 'Product' WHERE Item_ID='$_item'");
}
header( "Location: $url" );
?>