<?php require_once("common_db.inc.php") ?>
<?php   
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);

  $_list = $_GET['_list'];
  $_order = $_GET['_order'];
 if($_list == 'C') {
 	if($_order == 'A') {
 		$query = "SELECT * FROM Food ORDER BY Calories ASC";
 	}
 	else {
 		$query = "SELECT * FROM Food ORDER BY Calories DESC";
 }
 }
 else if($_list == 'S') {
 	if($_order == 'A') {
 		$query = "SELECT * FROM Food ORDER BY Servings ASC";
 	}
 	else {
 		$query = "SELECT * FROM Food ORDER BY Servings DESC";
 }
 }
 else if($_list == 'I') {
 	if($_order == 'A') {
 		$query = "SELECT * FROM Food ORDER BY Item_ID ASC";
 	}
 	else {
 		$query = "SELECT * FROM Food ORDER BY Item_ID DESC";
 }
 }
 else {
	$query = "select * from Food";
}
  $result = mysqli_query($link, $query);
  $query_3 = "select * from Product";
	$result_3 = mysqli_query($link, $query_3);   

?>

<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Spending Analysis</title>
</head>
<body>
<center>
<h1>Food</h1>


<table border="0">
<tr>
<td>
	
<FORM ACTION="Food.php" METHOD="GET"> Select Order:
   <select NAME ="_list" >
   <option value="NULL" selected> Sort </option>
		<option value="I">Item ID</option>
		<option value="C">Calories</option>
		<option value="S">Servings</option>
	</select>
  <select NAME ='_order' >
  	<option value="A">Ascending</option>
		<option value="D">Descending</option>
		</select>
  <INPUT TYPE="SUBMIT" VALUE = "Sort">
	</FORM>
	</td>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Undo Filters</a></td>
</tr>
<tr>
</tr>
</table>

<table border="1">
  <tr>
  <th>Option</th>
  	<th>Name</th>
  <th>Item ID</th>
	<th>Calories</th>
	<th>Servings</th>
	<th>Price</th>
	<th>Action</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
  <?php $_key = $record['Item_ID'];
  mysqli_data_seek($result_21, 0);
  $query_21 = "SELECT * FROM Product WHERE Item_ID = '$_key'";
  $result_21 = mysqli_query($link, $query_21);
  $record_2 = mysqli_fetch_array($result_21);
?>
  <tr>
    	<td>
	<form ACTION="Food_edit.php" METHOD="GET">
	<input type="hidden" name="_item" value="<?php print $record['Item_ID'];?>">
<input type="checkbox" name="_op" value="D">Delete
<INPUT TYPE="SUBMIT" VALUE = "Update">
</form>

</td>
   <td><?php print $record_2['Name'];?></td>
	<td><?php print $record['Item_ID'];?></td>
	<td><?php print $record['Calories'];?></td>
	<td><?php print $record['Servings'];?></td>
		<td>$<?php print $record_2['Price'];?></td>
	
	<td><a href="Food_edit.php?_item=<?php print $record['Item_ID'];?>&_op=E">Edit</a></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>
<h4>Add a New Item to Food</h4>
<FORM ACTION="Food_edit.php" METHOD="get" >
Select Item:
  <select NAME ='_item' >
	<?php while ($record = mysqli_fetch_array($result_3)): ?>
  <option name="_item" value="<?php print $record['Item_ID'];?>"><?php print $record['Item_ID'];?></option>  
	<?php endwhile; ?>
	</select>
<input type="hidden" name="_op" value="A">
	Calories: <input type="text" name="_cal">
	Servings: <input type="text" name="_ser">
  <INPUT TYPE="SUBMIT" VALUE = "Add">
	</FORM>

<h3>Quick View</h3>
<table border="1">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>
