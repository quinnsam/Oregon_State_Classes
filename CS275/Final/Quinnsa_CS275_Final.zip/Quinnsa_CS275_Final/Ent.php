<?php require_once("common_db.inc.php") ?>
<?php   
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);

  $_list = $_GET['_list'];
  $_order = $_GET['_order'];
if($_list == 'I') {
 	if($_order == 'A') {
 		$query = "SELECT * FROM Entertainment ORDER BY Item_ID ASC";
 	}
 	else {
 		$query = "SELECT * FROM Entertainment ORDER BY Item_ID DESC";
 }
 }
 else {
	$query = "select * from Entertainment";
}
  $result = mysqli_query($link, $query);  
	$query_2 = "select * from Product";
	$result_2 = mysqli_query($link, $query_2); 
?>

<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Spending Analysis</title>
</head>
<body>
<center>
<h1>Entertainment</h1>


<table border="0">
<tr>
<td>
	
<FORM ACTION="Ent.php" METHOD="GET"> Select Order:
   <select NAME ="_list" >
   <option value="NULL" selected> Sort </option>
		<option value="I">Item ID</option>
	</select>
  <select NAME ='_order' >
  	<option value="A">Ascending</option>
		<option value="D">Descending</option>
		</select>
  <INPUT TYPE="SUBMIT" VALUE = "Sort">
	</FORM>
	</td>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Undo Filters</a></td>
</tr>
<tr>
</tr>
</table>

<table border="1">
  <tr>
      <th>Options</th>
  	<th>Name</th>
  <th>Item ID</th>
	<th>With Who</th>
	<th>Description</th>
	<th>Price</th>
	<th>Action</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
  <?php $_key = $record['Item_ID'];
  mysqli_data_seek($result_21, 0);
  $query_21 = "SELECT * FROM Product WHERE Item_ID = '$_key'";
  $result_21 = mysqli_query($link, $query_21);
  $record_2 = mysqli_fetch_array($result_21);
?>
  <tr>
  	<td>
	<form ACTION="Ent_edit.php" METHOD="GET">
	<input type="hidden" name="_item" value="<?php print $record['Item_ID'];?>">
<input type="checkbox" name="_op" value="D">Delete
<INPUT TYPE="SUBMIT" VALUE = "Update">
</form>

</td>
   <td><?php print $record_2['Name'];?></td>
	<td><?php print $record['Item_ID'];?></td>
	<td><?php print $record['With_Who'];?></td>
	<td><?php print $record['Description'];?></td>
		<td>$<?php print $record_2['Price'];?></td>
	
	<td><a href="Ent_edit.php?_item=<?php print $record['Item_ID'];?>&_op=E">Edit</a></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>
<h4>Add a New Item to Entertainment</h4>
<table border="0" >
<tr>
<td>
<FORM ACTION="Ent_edit.php" METHOD="get" >
Select Item:
  <select NAME ='_item' >
	<?php while ($record = mysqli_fetch_array($result_2)): ?>
  <option name="_item" value="<?php print $record['Item_ID'];?>"><?php print $record['Item_ID'];?></option>  
	<?php endwhile; ?>
	</select>
<input type="hidden" name="_op" value="A">
	With Who: <input type="text" name="_ww">
	Description: <input type="text" name="_des">
  <INPUT TYPE="SUBMIT" VALUE = "Add">
	</FORM>
</td>
</tr>

</table>

<h3>Quick View</h3>
<table border="1">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>
