<?php require_once("common_db.inc.php") ?>
<?php   
  $_list = $_GET["_list"];
  $_order = $_GET["_order"];

  if(isset($_GET['Trans_ID'])) {
    // Note: In your application, you should validate and sanitize user input
    $Tran = $_GET['Trans_ID'];
    $query = "select * from Product where Trans_ID = '" . $Tran . "'";
  } elseif($_list != NULL) { 
  		if($_list == 'I') {
  			if($_order == 'A') {
  				$query = "select * from Product ORDER BY Item_ID ASC";
  			}
  			if($_order == 'D') {
  				$query = "select * from Product ORDER BY Item_ID DESC";
  			}
  		}
  		elseif($_list == 'P') {
  			if($_order == 'A') {
  				$query = "select * from Product ORDER BY Price ASC";
  			}
  			if($_order == 'D') {
  				$query = "select * from Product ORDER BY Price DESC";
  			}
  		}
  		elseif($_list == 'R') {
  			if($_order == 'A') {
  				$query = "select * from Product ORDER BY Rating ASC";
  			}
  			if($_order == 'D') {
  				$query = "select * from Product ORDER BY Rating DESC";
  			}
  		}
  		elseif($_list == 'N') {
  			if($_order == 'A') {
  				$query = "select * from Product ORDER BY Number ASC";
  			}
  			if($_order == 'D') {
  				$query = "select * from Product ORDER BY Number DESC";
  			}
  		}	
  	}
  	
  	else {
  	$query = "select * from Product";
  }
  
  $query_1 = "select DISTINCT Trans_ID from Product ORDER BY Trans_ID ASC";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);  
    
?>

<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Spending Analysis</title>
</head>
<body>
<center>
<h1>Products</h1>

<table border="0">
<tr>
<td>
	<FORM ACTION="Products.php" METHOD="GET" NAME = "Trans">
  Select Transaction:
  <select NAME ='Trans_ID' >
	<?php while ($record = mysqli_fetch_array($result_1)): ?>
  <option value="<?php print $record['Trans_ID'];?>"><?php print $record['Trans_ID'];?></option>  
	<?php endwhile; ?>
	</select>
  <INPUT TYPE="SUBMIT" VALUE = "Search">
	</FORM>
</td>
<td>
<FORM ACTION="Products.php" METHOD="GET" NAME = "Order">
  Select Order:
   <select NAME ="_list" >
		<option value="I">Item ID</option>
		<option value="P">Price</option>
		<option value="R">Rating</option>
		<option value="N">Number Purchased</option>
	</select>
  <select NAME ='_order' >
  	<option value="A">Ascending</option>
		<option value="D">Descending</option>
		</select>
  <INPUT TYPE="SUBMIT" VALUE = "Search">
	</FORM>
	</td>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Undo Filters</a></td>
</tr>
<tr>
</tr>
</table>




<table border="1">
  <tr>
    <th>Options</th>
    <th>Product Name</th>
    <th>Brand</th>
	<th>Item ID</th>
    <th>Transaction#</th>
	<th>Price</th>
	<th>Rating</th>
	<th># Purchased</th>
	<th>Action</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)): ?>  
  <tr>
	<td>
	<form ACTION="Product_edit.php" METHOD="GET">
	<input type="hidden" name="Item_ID" value="<?php print $record['Item_ID'];?>">
<input type="checkbox" name="_op" value="D">Delete
<INPUT TYPE="SUBMIT" VALUE = "Update">
</form>

</td>
    <td><?php print $record['Name'];?></td>
    <td><?php print $record['Brand'];?></td>
    	<td><?php print $record['Item_ID'];?></td>
    <td><?php print $record['Trans_ID'];?></td>
	<td>$<?php print $record['Price'];?></td>
	<td><?php print $record['Rating'];?></td>
	<td><?php print $record['Number'];?></td>
    
	<td><a href="Product_edit.php?Item_ID=<?php print $record['Item_ID'];?>&_op=E">Edit</a></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>
</table>
<h4>Add a New Product</h4>
<table border="0" >
<tr>
<td>
<FORM ACTION="Product_edit.php" METHOD="get" >
<input type="hidden" name="_op" value="A">
	Name: <input type="text" name="_name">
	Brand: <input type="text" name="_brand">
	Transaction #: <input type="int" name="_trans">
	</td>
	</tr>
	<tr>
	<td>
	Price: <input type="double" name="_price">
		Rating: <input type="int" name="_rate">
		# Purchased: <input type="int" name="_num">
  <INPUT TYPE="SUBMIT" VALUE = "Add">
	</FORM>
</td>
</tr>

</table>

<h3>Quick View</h3>
<table border="1">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>
