<!DOCTYPE html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Welcome</title>
</head>
<body style="background-color:#123456;">
<center>
<h1 style="color: White">Welcome to Sam's Spending Analysis</h1>
</center>
<p style="color: White">
Name: Sam Quinn<br>
OSU_ID: 931-907-154<br>
Class: CS275 TR 2:00 PM<br>
Date: 06/11/2013
</p>
<center>
<h3 style="color: White">Database Application Location</h3>
<p><a style="color: White" href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">http://web.engr.oregonstate.edu/~quinnsa/Welcome.php</a></p>
<br>
<h3 style="color: White">Database Login</h3>
<p style="color: White"><b>UserName: </b>cs275_quinnsa</p><br>
<p style="color: White"><b>Password: </b>7154</p><br>
<p style="color: White"><b>DataBase: </b>mysql.cs.orst.edu</p><br>
<a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php"><h1 style="color: Yellow">Enter</h1></a>
<br>

<h3 style="color: White">Quick View</h3>
<table border="1" style="background-color:white">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>