<?php require_once("common_db.inc.php") ?>
<?php   
	 /*if($_GET["_name"] > NULL) {
 	mysqli_query($link,"UPDATE Product SET Name=$_GET["_name"]
WHERE Item_ID='1'");
}*/
	$url = 'http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL';
  $_tran = $_GET["_tran"];
  $_str = $_GET["_str"];
  $_type = $_GET["_type"];
$_date = $_GET["_date"];
$_tot = $_GET["_tot"];
  $_op = $_GET["_op"];
  //echo $Ite;
  if($_op == NULL) {
  	header( "Location: $url" );
		exit();
}
  if($_op == 'A'){
  	//echo $_op;
  
 if (!mysqli_query($link,"INSERT INTO Transaction (Store, Type, Date, Total) VALUES ('$_str', '$_type', '$_date', '$_tot')")){
  die('Error: ' . mysqli_error($link));
  }
//echo "1 record added";
//mysqli_close($link);
header( "Location: $url" );
exit();
}  
 else if($_op == 'D') {
 //echo $_op;
 //echo $_item;
   if (!mysqli_query($link,"DELETE FROM Transaction WHERE Tran_ID = '$_tran'")){
  die('Error: ' . mysqli_error($link));
  }
header( "Location: $url" );
exit();
 }  
  
 else if($_op == 'E') {
if($_str != NULL) {
 	mysqli_query($link,"UPDATE Transaction SET Store='$_str'
	WHERE Tran_ID='$_tran'");
}
if($_type != NULL) {
 	mysqli_query($link,"UPDATE Transaction SET Type='$_type'
	WHERE Tran_ID='$_tran'");
}
if($_date != NULL) {
 	mysqli_query($link,"UPDATE Transaction SET Date='$_date'
	WHERE Tran_ID='$_tran'");
}
if($_tot != NULL) {
 	mysqli_query($link,"UPDATE Transaction SET Total='$_tot'
	WHERE Tran_ID='$_tran'");
}
}
  $query = "select * from Transaction WHERE Tran_ID='$_tran'";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);  
    
?>
<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Edit</title>
</head>
<body>
<table border="1">
  <tr>
  <th>Transaction #</th>
	<th>Store</th>
	<th>Type</th>
	<th>Date</th>
	<th>Total</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
   <tr>
   <td><?php print $record['Tran_ID'];?></td>
   	<td><?php print $record['Store'];?></td>
	<td><?php print $record['Type'];?></td>
	<td><?php print $record['Date'];?></td>
		<td>$<?php print $record['Total'];?></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>

<table border="0" >
<tr>
<td>
<FORM ACTION="Trans_edit.php" METHOD="get" >
<input type="hidden" name="_tran" value="<?php print $_tran ?>">
<input type="hidden" name="_op" value="E">
	Store <input type="text" name="_str">
	Type: <input type="text" name="_type">
	<br>
	Date(YYYY-MM-DD HH:MM:SS): <input type="datetime" name="_date">
	Total: <input type="double" name="_tot">
  <INPUT TYPE="SUBMIT" VALUE = "Edit">
	</FORM>
</td>
</tr>
<tr>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Go Back</a></td>
</tr>

</table>

</body>
</html>
