<?php require_once("common_db.inc.php") ?>
<?php   
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);
  $_store = $_GET['_store'];
  $_type = $_GET['_type'];
  $_list = $_GET['_list'];
  $_order = $_GET['_order'];
 
if ($_list == 'P'){
			if($_order == 'A') {
					$query = "select * from Transaction ORDER BY Total ASC";	
			}
			else {
					$query = "select * from Transaction ORDER BY Total DESC";
			}
		
	}
	else if ($_list == 'D'){
		if($_order == 'A') {
					$query = "select * from Transaction ORDER BY Date ASC";		
			}
			else {
					$query = "select * from Transaction ORDER BY Date DESC";
			}
	}
	else if ($_list == 'N'){
		if($_order == 'A') {
				$query = "select * from Transaction ORDER BY Tran_ID ASC";
			}
			else {
				$query = "select * from Transaction ORDER BY Tran_ID DESC";
			}
	}
	
	else {
		$query = "select * from Transaction";

 if($_store != 'NULL') 
  {
    // Note: In your application, you should validate and sanitize user input
    //echo $_type;
   // echo $_store;
   if($_type != 'NULL')
   {
    		
    		$query = "select * from Transaction where Type = '" . $_type . "' AND where Store = '" . $_store . "'";
   }
    	else 
    	{
    		$query = "select * from Transaction where Store = '" . $_store . "'";
    	}
}
else if($_type != 'NULL')
{
    		$query = "select * from Transaction where Type = '" . $_type . "'";
}
		}



  $query_1 = "select DISTINCT Store from Transaction";
  $query_2 = "select DISTINCT Type from Transaction";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);
  $result_2 = mysqli_query($link, $query_2);
?>

<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Spending Analysis</title>
</head>
<body>
<center>
<h1>Transactions</h1>

<FORM ACTION="Transactions.php?_store=NULL&_type=NULL" METHOD="GET" NAME = "TestForm">
  Select Store:
  <select NAME ='_store' >
  <option value="NULL" selected> Stores </option>
<?php while ($record = mysqli_fetch_array($result_1)): ?>
  <option value="<?php print $record['Store'];?>"><?php print $record['Store'];?></option>  
<?php endwhile; ?>
</select>
<select NAME ='_type' >
<option value="NULL" selected> Type </option>
<?php while ($record = mysqli_fetch_array($result_2)): ?>
  <option value="<?php print $record['Type'];?>"><?php print $record['Type'];?></option>  
<?php endwhile; ?>
</select>
  <INPUT TYPE="SUBMIT" VALUE = "Search">
</FORM>

<table border="0">
<tr>
<td>
	
<FORM ACTION="Transactions.php" METHOD="GET" NAME = "Order"> Select Order:
   <select NAME ="_list" >
   <option value="NULL" selected> Sort </option>
		<option value="P">Price</option>
		<option value="D">Date</option>
		<option value="N">Transaction #</option>
	</select>
  <select NAME ='_order' >
  	<option value="A">Ascending</option>
		<option value="D">Descending</option>
		</select>
  <INPUT TYPE="SUBMIT" VALUE = "Sort">
	</FORM>
	</td>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Undo Filters</a></td>
</tr>
<tr>
</tr>
</table>

<table border="1">
  <tr>
  <th>Option</th>
    <th>Transaction#</th>
	<th>Store</th>
	<th>Type</th>
	<th>Date</th>
	<th>Total</th>
	<th>Action</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)): ?>  
  <tr>
       	<td>
	<form ACTION="Trans_edit.php" METHOD="GET">
	<input type="hidden" name="_tran" value="<?php print $record['Tran_ID'];?>">
<input type="checkbox" name="_op" value="D">Delete
<INPUT TYPE="SUBMIT" VALUE = "Update">
</form>

</td>
    <td><?php print $record['Tran_ID'];?></td>
	<td><?php print $record['Store'];?></td>
	<td><?php print $record['Type'];?></td>
	<td><?php print $record['Date'];?></td>
		<td>$<?php print $record['Total'];?></td>
	
    
	<td><a href="Trans_edit.php?_tran=<?php print $record['Tran_ID'];?>&_op=E">Edit</a></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>

<h4>Add a New Transaction</h4>
<FORM ACTION="Trans_edit.php" METHOD="get" >
<input type="hidden" name="_op" value="A">
	Store: <input type="text" name="_str">
	Type: <input type="text" name="_type">
	<br>
	Date(YYYY-MM-DD HH:MM:SS): <input type="datetime" name="_date">
	Total: <input type="double" name="_tot">
  <INPUT TYPE="SUBMIT" VALUE = "Add">
	</FORM>

<h3>Quick View</h3>
<table border="1">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>
