<?php require_once("common_db.inc.php") ?>
<?php   
	 /*if($_GET["_name"] > NULL) {
 	mysqli_query($link,"UPDATE Product SET Name=$_GET["_name"]
WHERE Item_ID='1'");
}*/
	$url = 'http://web.engr.oregonstate.edu/~quinnsa/Food.php';
  $_item = $_GET["_item"];
  $_cal = $_GET["_cal"];
  $_ser = $_GET["_ser"];
  $_op = $_GET["_op"];
  //echo $Ite;
  if($_op == NULL) {
  	header( "Location: $url" );
		exit();
}
  if($_op == 'A'){
  	//echo $_op;
  
 if (!mysqli_query($link,"INSERT INTO Food (Item_ID, Calories, Servings) VALUES ('$_item', '$_cal', '$_ser')")){
  die('Error: ' . mysqli_error($link));
  }
//echo "1 record added";
//mysqli_close($link);
header( "Location: $url" );
exit();
}  
 else if($_op == 'D') {
 echo $_op;
 echo $_item;
   if (!mysqli_query($link,"DELETE FROM Food WHERE Item_ID = '$_item'")){
  die('Error: ' . mysqli_error($link));
  }
header( "Location: $url" );
exit();
 }  
  
 else if($_op == 'E') {
if($_cal != NULL) {
 	mysqli_query($link,"UPDATE Food SET Calories='$_cal'
	WHERE Item_ID='$_item'");
}
if($_ser != NULL) {
 	mysqli_query($link,"UPDATE Food SET Servings='$_ser'
	WHERE Item_ID='$_item'");
}
}
  $query = "select * from Food WHERE Item_ID='$_item'";
  //$query_1 = "select DISTINCT $_GET["Item_ID"] from Product ORDER BY Item_ID ASC";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);  
    
?>
<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Edit</title>
</head>
<body>
<table border="1">
  <tr>
  	<th>Name</th>
  <th>Item ID</th>
	<th>Calories</th>
	<th>Servings</th>
	<th>Price</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
  <?php $_key = $record['Item_ID'];
  mysqli_data_seek($result_21, 0);
  $query_21 = "SELECT * FROM Product WHERE Item_ID = '$_key'";
  $result_21 = mysqli_query($link, $query_21);
  $record_2 = mysqli_fetch_array($result_21);
?>
  <tr>
   <td><?php print $record_2['Name'];?></td>
   	<td><?php print $record['Item_ID'];?></td>
	<td><?php print $record['Calories'];?></td>
	<td><?php print $record['Servings'];?></td>
		<td>$<?php print $record_2['Price'];?></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>

<table border="0" >
<tr>
<td>
<FORM ACTION="Food_edit.php" METHOD="get" >
<input type="hidden" name="_item" value="<?php print $_item ?>">
<input type="hidden" name="_op" value="E">
	Calories: <input type="text" name="_cal">
	Servings: <input type="text" name="_ser">
  <INPUT TYPE="SUBMIT" VALUE = "Edit">
	</FORM>
</td>
</tr>
<tr>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Go Back</a></td>
</tr>

</table>

</body>
</html>
