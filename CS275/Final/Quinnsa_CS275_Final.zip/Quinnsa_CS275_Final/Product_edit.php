<?php require_once("common_db.inc.php") ?>
<?php   
	 /*if($_GET["_name"] > NULL) {
 	mysqli_query($link,"UPDATE Product SET Name=$_GET["_name"]
WHERE Item_ID='1'");
}*/
	$url = 'http://web.engr.oregonstate.edu/~quinnsa/Products.php';
  $Ite = $_GET["Item_ID"];
  $_name = $_GET["_name"];
  $_brand = $_GET["_brand"];
  $_price = $_GET["_price"];
  $_trans = $_GET["_trans"];
  $_num = $_GET["_num"];
  $_rate = $_GET["_rate"];
  $_op = $_GET["_op"];
  //echo $Ite;
  if($_op == NULL) {
  	header( "Location: $url" );
		exit();
}
  if($_op == 'A'){
  	//echo $_op;
  
 if (!mysqli_query($link,"INSERT INTO Product (Trans_ID, Brand, Price, Name, Rating, Number) VALUES ('$_trans', '$_brand', '$_price', '$_name', '$rate', '$_num')")){
  die('Error: ' . mysqli_error($link));
  }
//echo "1 record added";
//mysqli_close($link);
header( "Location: $url" );
exit();
}  
 else if($_op == 'D') {
 	//echo $_op;
 //	echo $Ite;
   if (!mysqli_query($link,"DELETE FROM Product WHERE Item_ID='$Ite'")){
  die('Error: ' . mysqli_error($link));
  }
header( "Location: $url" );
exit();
 }  
  
 else if($_op == 'E') {
if($_name != NULL) {
 	mysqli_query($link,"UPDATE Product SET Name='$_name'
	WHERE Item_ID='$Ite'");
}
if($_brand != NULL) {
 	mysqli_query($link,"UPDATE Product SET Brand='$_brand'
	WHERE Item_ID='$Ite'");
}
if($_price != NULL) {
 	mysqli_query($link,"UPDATE Product SET Price='$_price'
	WHERE Item_ID='$Ite'");
}
if($_num != NULL) {
 	mysqli_query($link,"UPDATE Product SET Number='$_num'
	WHERE Item_ID='$Ite'");
}
if($_rate != NULL) {
 	mysqli_query($link,"UPDATE Product SET Rating='$_rate'
	WHERE Item_ID='$Ite'");
}
if($_trans != NULL) {
 	mysqli_query($link,"UPDATE Product SET Trans_ID='$_trans'
	WHERE Item_ID='$Ite'");
}
}
  $query = "select * from Product WHERE Item_ID='$Ite'";
  //$query_1 = "select DISTINCT $_GET["Item_ID"] from Product ORDER BY Item_ID ASC";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);  
    
?>
<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Edit</title>
</head>
<body>
<table border="1">
  <tr>
    <th>Product Name</th>
    <th>Brand</th>
	<th>Item ID</th>
    <th>Transaction#</th>
	<th>Price</th>
	<th>Rating</th>
	<th># Purchased</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)): ?>  
 <tr>
    <td><?php print $record['Name'];?></td>
    <td><?php print $record['Brand'];?></td>
    	<td><?php print $record['Item_ID'];?></td>
    <td><?php print $record['Trans_ID'];?></td>
	<td>$<?php print $record['Price'];?></td>
	<td><?php print $record['Rating'];?></td>
	<td><?php print $record['Number'];?></td>
   </tr> 
  <?php endwhile; mysqli_free_result($result);?>
</table>

<table border="0" >
<tr>
<td>
<FORM ACTION="Product_edit.php" METHOD="get" >
<input type="hidden" name="Item_ID" value="<?php print $Ite ?>">
<input type="hidden" name="_op" value="E">
	Name: <input type="text" name="_name">
	Brand: <input type="text" name="_brand">
	Transaction #: <input type="int" name="_trans">
	</td>
	</tr>
	<tr>
	<td>
	Price: <input type="double" name="_price">
		Rating: <input type="int" name="_rate">
		# Purchased: <input type="int" name="_num">
  <INPUT TYPE="SUBMIT" VALUE = "Edit">
	</FORM>
</td>
</tr>
<tr>
<td>
<a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Go Back</a>
</td>
</tr>
</table>
</body>
</html>
