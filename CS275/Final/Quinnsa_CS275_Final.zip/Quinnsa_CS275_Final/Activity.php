<?php require_once("common_db.inc.php") ?>
<?php   
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);
  //$query_0 = "select * from Product";
  //$result_0 = mysqli_query($link, $query_0);

  $_list = $_GET['_list'];
  $_order = $_GET['_order'];
  if ($_list == 'P'){
			if($_order == 'A') {
					$query = "select * from Activity ORDER BY Price ASC";	
			}
			else {
					$query = "select * from Activity ORDER BY Price DESC";
			}
		
	}
	else if ($_list == 'T'){
		if($_order == 'A') {
					$query = "select * from Activity ORDER BY Tran_ID ASC";	
			}
			else {
					$query = "select * from Activity ORDER BY Tran_ID DESC";	
			}
	}
	else if ($_list == 'I'){
		if($_order == 'A') {
				$query = "select * from Activity ORDER BY Activity_ID ASC";
			}
			else {
				$query = "select * from Activity ORDER BY Activity_ID DESC";	
			}
	}
	
	else {

	$query = "select * from Activity";
}
  $result = mysqli_query($link, $query);  

?>

<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Spending Analysis</title>
</head>
<body>
<center>
<h1>Activities</h1>


<table border="0">
<tr>
<td>
	
<FORM ACTION="Activity.php" METHOD="GET"> Select Order:
   <select NAME ="_list" >
   <option value="NULL" selected> Sort </option>
		<option value="I">Activity ID</option>
		<option value="T">Transaction #</option>
		<option value="P">Price</option>
	</select>
  <select NAME ='_order' >
  	<option value="A">Ascending</option>
		<option value="D">Descending</option>
		</select>
  <INPUT TYPE="SUBMIT" VALUE = "Sort">
	</FORM>
	</td>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Go Back</a></td>
</tr>
<tr>
</tr>
</table>

<table border="1">
  <tr>
   <th>Options</th>
  	<th>Activity ID</th>
  <th>Description</th>
	<th>Location</th>
	<th>Transaction #</th>
	<th>Price</th>
	<th>Action</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
  
  <tr>
  <td>
	<form ACTION="Activity_edit.php" METHOD="GET">
	<input type="hidden" name="_ai" value="<?php print $record['Activity_ID'];?>">
<input type="checkbox" name="_op" value="D">Delete
<INPUT TYPE="SUBMIT" VALUE = "Update">
</form>

</td>
   <td><?php print $record['Activity_ID'];?></td>
	<td><?php print $record['Description'];?></td>
	<td><?php print $record['Location'];?></td>
	<td><?php print $record['Tran_ID'];?></td>
		<td>$<?php print $record['Price'];?></td>
	
	<td><a href="Activity_edit.php?_ai=<?php print $record['Activity_ID'];?>&_op=E">Edit</a></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>
<h4>Add a New Activity</h4>
<table border="0" >
<tr>
<td>
<FORM ACTION="Activity_edit.php" METHOD="get" >
<input type="hidden" name="_op" value="A">
	Description: <input type="text" name="_des">
	Location: <input type="text" name="_loc">
	</td>
	</tr>
	<tr>
	<td>
	Transaction ID: <input type="int" name="_trans">
		Price: <input type="int" name="_price">
  <INPUT TYPE="SUBMIT" VALUE = "Add">
	</FORM>
</td>
</tr>

</table>

<h3>Quick View</h3>
<table border="1">
<tr>
	<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Welcome.php">Home</a></td>
		<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Activity</a></td>
			<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Clothes.php">Clothes</a></td>
				<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Ent.php">Entertainment</a></td>
					<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Food.php">Food</a></td>
						<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Transactions.php?_store=NULL&_type=NULL">Transactions</a></td>
							<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Products.php">Products</a></td>
</tr>
</table>
</center>
</body>
</html>
