<?php require_once("common_db.inc.php") ?>
<?php   
	 /*if($_GET["_name"] > NULL) {
 	mysqli_query($link,"UPDATE Product SET Name=$_GET["_name"]
WHERE Item_ID='1'");
}*/
	$url = 'http://web.engr.oregonstate.edu/~quinnsa/Activity.php';
  $_ai = $_GET["_ai"];
  $_des = $_GET["_des"];
  $_loc = $_GET["_loc"];
  $_price = $_GET["_price"];
  $_trans = $_GET["_trans"];
  $_num = $_GET["_num"];
  $_op = $_GET["_op"];
  //echo $Ite;
  if($_op == NULL) {
  	header( "Location: $url" );
		exit();
}
  if($_op == 'A'){
  	//echo $_op;
  
 if (!mysqli_query($link,"INSERT INTO Activity (Activity_ID, Description, Price, Location, Tran_ID) VALUES ('$_ai', '$_des', '$_price', '$_loc', '$_trans')")){
  die('Error: ' . mysqli_error($link));
  }
//echo "1 record added";
//mysqli_close($link);
header( "Location: $url" );
exit();
}  
 else if($_op == 'D') {
 	//echo $_op;
 //	echo $Ite;
   if (!mysqli_query($link,"DELETE FROM Activity WHERE Activity_ID='$_ai'")){
  die('Error: ' . mysqli_error($link));
  }
header( "Location: $url" );
exit();
 }  
  
 else if($_op == 'E') {
if($_des != NULL) {
 	mysqli_query($link,"UPDATE Activity SET Description='$_des'
	WHERE Activity_ID='$_ai'");
}
if($_loc != NULL) {
 	mysqli_query($link,"UPDATE Activity SET Location='$_loc'
	WHERE Activity_ID='$_ai'");
}
if($_trans != NULL) {
 	mysqli_query($link,"UPDATE Activity SET Tran_ID='$_trans'
	WHERE Activity_ID='$_ai'");
}
if($_price != NULL) {
 	mysqli_query($link,"UPDATE Activity SET Price='$_price'
	WHERE Activity_ID='$_ai'");
}
}
  $query = "select * from Activity WHERE Activity_ID='$_ai'";
  //$query_1 = "select DISTINCT $_GET["Item_ID"] from Product ORDER BY Item_ID ASC";
  $result = mysqli_query($link, $query);  
  $result_1 = mysqli_query($link, $query_1);  
    
?>
<!doctype html>
<html lang="en">
<head>  
  <meta charset="utf-8" />
  <title>Edit</title>
</head>
<body>
<table border="1">
  <tr>
  	<th>Activity ID</th>
  <th>Description</th>
	<th>Location</th>
	<th>Transaction #</th>
	<th>Price</th>
  </tr>
  
 <?php mysqli_data_seek($result, 0); 
  while ($record = mysqli_fetch_array($result)):?> 
  
  <tr>
   <td><?php print $record['Activity_ID'];?></td>
	<td><?php print $record['Description'];?></td>
	<td><?php print $record['Location'];?></td>
	<td><?php print $record['Tran_ID'];?></td>
		<td>$<?php print $record['Price'];?></td>
  </tr>
  <?php endwhile; mysqli_free_result($result);?>

</table>

<table border="0" >
<tr>
<td>
<FORM ACTION="Activity_edit.php" METHOD="get" >
<input type="hidden" name="_ai" value="<?php print $_ai ?>">
<input type="hidden" name="_op" value="E">
	Description: <input type="text" name="_des">
	Location: <input type="text" name="_loc">
	</td>
	</tr>
	<tr>
	<td>
	Transaction ID: <input type="int" name="_trans">
		Price: <input type="int" name="_price">
  <INPUT TYPE="SUBMIT" VALUE = "Edit">
	</FORM>
</td>
</tr>
<tr>
<td><a href="http://web.engr.oregonstate.edu/~quinnsa/Activity.php">Go Back</a></td>
</tr>

</table>

</body>
</html>
