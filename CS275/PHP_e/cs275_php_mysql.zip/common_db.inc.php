<?php 
  define("DB_SERVER", "mysql.cs.orst.edu");
  define("DB_USER", "YOUR_USERNAME");  
  define("DB_PASSWORD", "YOUR_PASSWORD");
  define("DB_NAME", "YOUR_DB_NAME"); 
  
  $link = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD) 
    or die ("Unable to connect to server<br>");
	
  mysqli_select_db($link, DB_NAME) 
   or die ("Unable to select database " . DB_NAME . "<br>");   
?>