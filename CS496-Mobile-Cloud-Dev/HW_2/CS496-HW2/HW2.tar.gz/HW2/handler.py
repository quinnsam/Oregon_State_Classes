import webapp2
import os
import jinja2
import base_page
from google.appengine.ext import ndb
import db_defs

class MainPage(base_page.BaseHandler):
    def __init__(self, request, response):
        self.initialize(request, response)
        self.template_varibles = {}


    def get(self):
        """Return a friendly HTTP greeting."""
        self.render('main.html')

    def post(self):
        action = self.request.get('action')
        if action == 'add_key':
            k = ndb.Key(db_defs.Public_Keys, self.app.config.get('default-key'))
            storekey = db_defs.Public_Keys(parent=k)
            storekey.fullname = self.request.get('full-name')
            storekey.email = self.request.get('email')
            storekey.encryptionType = self.request.get('Encryption-type')
            storekey.bit = int(self.request.get('bit-strength'))
            storekey.expDate = self.request.get('exp-date')
            storekey.expTime = self.request.get('exp-time')
            storekey.exp = self.request.get('expiration')
            storekey.key = self.request.get('pubkey')
            storekey.put()
            self.render('main.html', {'message':'Added ' + storekey.fullname + ' to the DataBase.'})
        else:
            self.render('main.html', {'message':'Action' + action + ' is unknown.'})



        #self.template_varibles['form_content'] = {}
        #template = JINJA_ENVIRONMENT.get_template('main.html')
        #for i in self.request.arguments():
        #    self.template_varibles['form_content'][i] = self.request.get(i)
        #self.response.write(template.render(self.template_varibles))
        #if action == '

