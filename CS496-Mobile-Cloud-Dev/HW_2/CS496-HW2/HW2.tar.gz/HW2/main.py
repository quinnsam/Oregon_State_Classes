import webapp2

config = {'default-key':'base-data'}

app = webapp2.WSGIApplication([
    ('/', 'handler.MainPage')
    ], debug=True, config=config)


