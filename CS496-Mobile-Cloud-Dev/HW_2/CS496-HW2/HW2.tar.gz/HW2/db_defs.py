from google.appengine.ext import ndb

class Public_Keys(ndb.Model):
    fullname = ndb.StringProperty(required=True)
    email = ndb.StringProperty(required=True)
    encryptionType = ndb.StringProperty(required=True)
    bit = ndb.IntegerProperty(required=True)
    expDate = ndb.StringProperty()
    expTime  = ndb.StringProperty()
    exp = ndb.StringProperty(required=True)
    key = ndb.StringProperty(required=True)

